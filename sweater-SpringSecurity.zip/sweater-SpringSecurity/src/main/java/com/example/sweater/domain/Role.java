package com.example.sweater.domain;

public enum Role {
    USER;
}
